package com.sai.spring.springjdbc.employee.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sai.spring.springjdbc.employee.dao.EmployeeDao;
import com.sai.spring.springjdbc.employee.dto.Employee;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ct = new ClassPathXmlApplicationContext(
				"com/sai/spring/springjdbc/employee/test/config.xml");
		EmployeeDao edao = (EmployeeDao) ct.getBean("employeedao");

		// Employee employee = new Employee();
		// employee.setId(2);
		// employee.setFirstName("sai");
		// employee.setLastName("krish");
		// int x = edao.create(employee);
		// int x=edao.update(employee);
		// int x=edao.delete(2);
		//Employee emp = edao.read(1);
		List<Employee> emp = edao.read();
		System.out.println(emp);
	}

}
