package com.sai.spring.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ct = new ClassPathXmlApplicationContext("com/sai/spring/springjdbc/config.xml");
		JdbcTemplate jdbcTemplate = (JdbcTemplate) ct.getBean("jdbcTemplate");
		String sql = "insert into employee values(?,?,?)";
		int x = jdbcTemplate.update(sql, 1, "sai", "krishna");
		System.out.println(x);
	}

}
