package com.sai.spring.springjdbc.employee.dao.impl;

import java.sql.JDBCType;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

import com.sai.spring.springjdbc.employee.dao.EmployeeDao;
import com.sai.spring.springjdbc.employee.dao.rowmapper.EmployeeRowMapper;
import com.sai.spring.springjdbc.employee.dto.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private JdbcTemplate jdbcTemplate;

	@Override
	public int create(Employee employee) {
		String sql = "insert into employee values(?,?,?)";
		int x = jdbcTemplate.update(sql, employee.getId(), employee.getFirstName(), employee.getLastName());
		return x;
	}

	public JdbcTemplate getJdbcTemplate() {
		return jdbcTemplate;
	}

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public int update(Employee employee) {
		String sql = "update employee set firstname=?,lastname=? where id=?";
		int x = jdbcTemplate.update(sql, employee.getFirstName(), employee.getLastName(), employee.getId());
		return x;

	}

	@Override
	public int delete(int id) {
		String sql = "delete from employee where id=?";
		int x = jdbcTemplate.update(sql, id);
		return x;
	}

	@Override
	public Employee read(int id) {
		String sql = "select * from employee where id=?";
		EmployeeRowMapper rm = new EmployeeRowMapper();
		Employee emp = jdbcTemplate.queryForObject(sql, rm, id);
		return emp;
	}

	@Override
	public List<Employee> read() {
		String sql="select * from employee";
		EmployeeRowMapper rm = new EmployeeRowMapper();
		List<Employee> result = jdbcTemplate.query(sql, rm);
		return result;
	}

}
